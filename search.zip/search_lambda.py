def lambda_handler():
    """Prints 'Hello, World!' to the console."""
    print("Hello, World!")

# Example usage:
lambda_handler()

# End.

