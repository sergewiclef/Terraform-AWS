def search_lambda():
    """Prints 'Hello, World!' to the console."""
    print("Hello, World!")

# Example usage:
search_lambda()

